package com.ankit.test;

public class Main {
	public void message(){
		System.out.println("Good Morning");
	}

	public static void main(String[] args) {
		System.out.println("welcome to git hub");
        add(10,20);
	}
	public static int add(int a,int b){
		return a+b;
	}

}
