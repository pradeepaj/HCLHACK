package com.ankit.test;

public class Message {

	public static void main(String[] args) {
		System.out.println("hello welcome to java");
		System.out.println("Ankit singh");
	}

}
